import pandas as pd
import matplotlib.pyplot as plt


def col_people(file_path, date):
    areas_of_training = {
        '09.03.01': 'Информатика и вычислительная техника',
        '09.03.01(ИИ)': 'Алгоритмы искусственного интеллекта',
        '09.03.03': 'Прикладная информатика',
        '09.03.04': 'Программная инженерия',
        '10.03.01': 'Безопасность компьютерных систем',
        '11.00.00': 'Электроника, радиотехника и системы связи',
        '27.03.04': 'Управление в технических системах',
        '29.03.03': 'Технология полиграфического и упаковочного производства'
    }
    areas_of_training_nums = list(areas_of_training.values())
    excel_file = pd.read_excel(file_path)
    avg = excel_file['количество поступающих'].tolist()

    fig, ax = plt.subplots(figsize=(12, 7))
    ax.pie(avg, labels=areas_of_training_nums, autopct='%1.1f%%')
    plt.savefig(f'Круговая диаграмма процента поступающих на каждое направление бакалавриата ИРИТ-РТФ за {date}.png', dpi=300)
    plt.show()


file_path = f'pivot_table-07-13.xlsx'
col_people(file_path, '2023-07-13')