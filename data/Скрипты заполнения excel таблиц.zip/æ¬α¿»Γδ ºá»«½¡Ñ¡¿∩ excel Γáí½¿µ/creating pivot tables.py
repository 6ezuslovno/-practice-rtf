import pandas as pd
import xlsxwriter

# Создание таблицы с информацией о доступных местах
seats_data = {
    'program': [
        'Информатика и вычислительная техника',
        'Алгоритмы искусственного интеллекта',
        'Прикладная информатика',
        'Программная инженерия',
        'Безопасность компьютерных систем',
        'Электроника, радиотехника и системы связи',
        'Управление в технических системах',
        'Технология полиграфического и упаковочного производства'
    ],
    'seats': [
        120, 100, 199, 230, 80, 150, 50, 45
    ]
}

new_names = {'Электроника, радиотехника и системы связи (11.03.01, 11.03.02, 11.03.03)': 'Электроника, радиотехника и системы связи',
             'Радиотехника': 'Электроника, радиотехника и системы связи',
             'Инфокоммуникационные технологии и системы связи': 'Электроника, радиотехника и системы связи',
             'Конструирование и технология электронных средств': 'Электроника, радиотехника и системы связи'}

# Создание DataFrame из таблицы с информацией о доступных местах
seats_df = pd.DataFrame(seats_data)

# Загрузка данных о поступающих из файла Excel
df = pd.read_excel('table of incoming radio faculty 2023-07-13.xlsx')
df['program'] = df['program'].map(lambda x: new_names[x] if x in new_names else x)
filtered_df = df[(df['compensation'] == 'бюджетная основа') & (df['priority'] == 1) & ((df['status'] == 'Рейтинг') | (df['status'] == 'К зачислению')) & (df['is_without_tests'] == False)]
filtered_df_no_priority = df[(df['compensation'] == 'бюджетная основа') & ((df['status'] == 'Рейтинг') | (df['status'] == 'К зачислению')) & (df['is_without_tests'] == False)]

grouped_df_no_priority = filtered_df_no_priority.groupby('program').agg({'regnum': 'count'}).reset_index()

# Группировка данных по программе и подсчет количества поступающих, приоритета 1 и статуса "К зачислению"
grouped_df = filtered_df.groupby('program').agg(
    {'priority': lambda x: sum(x == 1),
     'status': lambda x: sum(x == 'К зачислению'),
     'total_mark': 'mean'}
).reset_index()

merged_grouped_df = pd.merge(grouped_df, grouped_df_no_priority, on='program', how='left')

# Объединение с таблицей о доступных местах
merged_df = pd.merge(seats_df, merged_grouped_df, on='program', how='left')
merged_df['количество поступающих'] = merged_grouped_df['regnum']
merged_df['количество мест'] = seats_df['seats']

# Рассчет процента набора по программе
merged_df['набор в % по программе'] = (merged_df['status'] / merged_df['количество мест']) * 100

# Подсчет суммы баллов и количества студентов на каждой программе
df_sorted = filtered_df.sort_values(by='total_mark', ascending=False)
group_sorted = df_sorted.groupby('program').head(300)  # Выбираем первые 200 записей для каждой программы
group_sorted = group_sorted.reset_index(drop=True)  # Сбрасываем индексы для удобства работы
programs = {
    'Информатика и вычислительная техника': 119,
    'Алгоритмы искусственного интеллекта': 99,
    'Прикладная информатика': 198,
    'Программная инженерия': 229,
    'Безопасность компьютерных систем': 79,
}

for program, index in programs.items():
    place_program = group_sorted.loc[group_sorted['program'] == program].iloc[index]
    print(place_program['total_mark'])

avg_score_df = filtered_df.groupby('program').agg({'total_mark': 'sum', 'regnum': 'count'}).reset_index()
avg_score_df.columns = ['program', 'сумма баллов', 'количество студентов']

# Рассчет среднего балла
avg_score_df['средний балл'] = avg_score_df['сумма баллов'] // avg_score_df['количество студентов']

# Объединение данных
merged_df = pd.merge(merged_df, avg_score_df, on='program', how='left')

# Вывод сводной таблицы
pivot_table = merged_df[['program', 'seats', 'regnum', 'priority', 'status', 'средний балл', 'набор в % по программе']]
pivot_table.columns = ['Программа', 'количество мест', 'количество поступающих', 'Приоритет 1', 'К зачислению', 'Средний балл', 'Набор в % по программе']

# Сохранение в файл Excel с форматированием
writer = pd.ExcelWriter('pivot_table-07-13-contract.xlsx', engine='xlsxwriter')
pivot_table.to_excel(writer, index=False, sheet_name='Sheet1', header=True)

# Получение объекта рабочей книги и листа
workbook = writer.book
worksheet = writer.sheets['Sheet1']

# Настройка форматирования заголовков
header_format = workbook.add_format({'bold': True, 'font_size': 14, 'align': 'center'})
worksheet.set_row(0, 30)  # Установка высоты строки для заголовков

# # Запись заголовка "Программа"
# worksheet.merge_range('A1:A1', 'Программа', header_format)
#
# # Запись заголовка "Бюджет"
# worksheet.merge_range('B1:G1', 'Бюджет', header_format)
#
# # Настройка ширины столбцов
# worksheet.set_column('A:A', 63)
# worksheet.set_column('B:G', 15)

# writer.save()
writer.close()