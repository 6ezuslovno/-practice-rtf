import pandas as pd
import matplotlib.pyplot as plt

areas_of_training = {
        '09.03.01': 'Информатика и вычислительная техника',
        '09.03.01(ИИ)': 'Алгоритмы искусственного интеллекта',
        '09.03.03': 'Прикладная информатика',
        '09.03.04': 'Программная инженерия',
        '10.03.01': 'Безопасность компьютерных систем',
        '11.00.00': 'Электроника, радиотехника и системы связи (11.03.01, 11.03.02, 11.03.03)',
        '27.03.04': 'Управление в технических системах',
        '29.03.03': 'Технология полиграфического и упаковочного производства'
    }
areas_of_training_nums = list(areas_of_training.keys())
areas_of_training_prog = list(areas_of_training.values())

excel_file = pd.read_excel('table of incoming radio faculty 2023-07-13.xlsx')

applications_count = [len(excel_file[excel_file['program'] == area]) for area in areas_of_training_prog]
bar_colors = ['tab:red', 'tab:blue', 'tab:purple', 'tab:orange', 'tab:pink', 'tab:gray', 'tab:cyan', 'tab:green']

fig, ax = plt.subplots(figsize=(12, 7))
ax.bar(areas_of_training_nums, applications_count, color=bar_colors)

ax.set_ylabel('Количество заявлений')
ax.set_title('Заявления по областям обучения')
# ax.legend(title='Области обучения')
for i, v in enumerate(applications_count):
    ax.text(i, v+0.2, str(v), ha='center')

plt.xticks(rotation=45)
plt.tight_layout()
plt.show()