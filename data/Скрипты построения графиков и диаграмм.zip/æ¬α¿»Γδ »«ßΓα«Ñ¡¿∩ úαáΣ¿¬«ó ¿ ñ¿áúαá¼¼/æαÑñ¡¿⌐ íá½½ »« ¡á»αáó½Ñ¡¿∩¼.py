import pandas as pd
import matplotlib.pyplot as plt


def calculate_average_marks(file_path, date):
    areas_of_training = {
        '09.03.01': 'Информатика и вычислительная техника',
        '09.03.01(ИИ)': 'Алгоритмы искусственного интеллекта',
        '09.03.03': 'Прикладная информатика',
        '09.03.04': 'Программная инженерия',
        '10.03.01': 'Безопасность компьютерных систем',
        '11.00.00': 'Электроника, радиотехника и системы связи',
        '27.03.04': 'Управление в технических системах',
        '29.03.03': 'Технология полиграфического и упаковочного производства'
    }
    areas_of_training_nums = list(areas_of_training.keys())
    excel_file = pd.read_excel(file_path)
    avg = excel_file['Средний балл'].tolist()

    fig, ax = plt.subplots(figsize=(12, 7))
    bar_labels = ['red', 'blue', 'purple', 'orange', 'pink', 'gray', 'cyan', 'green']
    bar_colors = ['tab:red', 'tab:blue', 'tab:purple', 'tab:orange', 'tab:pink', 'tab:gray', 'tab:cyan', 'tab:green']

    ax.bar(areas_of_training_nums, avg, color=bar_colors)

    ax.set_title(f'Средний балл по направлениям на {date}')

    # ax.legend(title='Направления', bbox_to_anchor=(0.82, 0.2), loc='center left')

    for i, v in enumerate(avg):
        ax.text(i, v + 0.2, str(v), ha='center')
    plt.savefig(f'Столбчатая диаграмма среднего балла на каждое направление бакалавриата ИРИТ-РТФ за {date}.png', dpi=300)
    plt.show()


file_path = f'pivot_table-07-13.xlsx'
calculate_average_marks(file_path, '2023-07-13')